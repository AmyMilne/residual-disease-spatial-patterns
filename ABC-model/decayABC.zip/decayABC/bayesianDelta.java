package ModelFinal;

import HAL.Tools.FileIO;

import java.io.IOException;

public class bayesianDelta extends ExampleCell {
    public static void main(String[]args) throws IOException {


        int noPriors = 1000;

        // name destination folder
        String destinationFolder = "";

        // log start time of algorithm
        long startTime = System.nanoTime();

        int noDays = 100;

        int deltaTHatMultiplier = 10;

        int timesteps = (int) ((noDays + 1) * timestepPerDay);

        int timestepsHat = timesteps / deltaTHatMultiplier;

        double [][] bayesianPriors = new double[1][2];

        // use calibrated values for pNaught and beta
        bayesianPriors [0][0] = 0.256; // pNaught
        bayesianPriors [0][1] = 1.25; // beta

        double [] bayesianPriorsDelta = readPriorsDelta(destinationFolder + "BayesianPriorsDelta.csv", noPriors);

        int noSims = 10;

        FileIO cancerTimeSeries = new FileIO(destinationFolder + "cancerTimeSeries.csv", "w");
        // Write data headings
        cancerTimeSeries.Write("sim,time,cellCount,diameter,delta\n");

        for (int i = 0; i < bayesianPriorsDelta.length; i++) {

            for (int k = 0; k < noSims; k++) {

                double betaVary = bayesianPriors[0][1] * timestepDay;

                double deltaVary = bayesianPriorsDelta[i] * timestepDay;

                boolean boundaryReached = false;
                // declare time and population storage arrays
                double[] timeVector = new double[timestepsHat + 1];
                double[] cancerPopulation = new double[timestepsHat + 1];
                double[] quiescentCancerPopulation = new double[timestepsHat + 1];

                // set up model
                ExampleGrid model = new ExampleGrid(x, y);

                // read vessel initialisation
                int[][] vesselSetUp = model.readVesselInitialisation(destinationFolder +
                        "vesselLocations.csv", nV);

                // initialise vessel cells
                model.initialiseVesselCells(vesselSetUp, nV, VESSEL);

                // determine position and age of initial cancer population
                int initialCancerCount = model.countInitialCancer(destinationFolder +
                        "cancerInitialCount.csv");
                double[][] initialCancer = model.initialCancerSetUp(destinationFolder +
                        "locationsCancer.csv", initialCancerCount);

                // determine intial proliferation signal over domain
                double[] proliferationSignalInit = model.initialProliferationSignal(
                        destinationFolder + "valuesProliferationSignal.csv", x, y);

                // initialise proliferation signal
                model.initialiseProliferationSignal(proliferationSignalInit);

                // initialise cancer
                cellIDCount = model.initialiseCancer(initialCancer, CANCER, QUIESCENTCANCER, cellIDCount, parentCellHp,
                        parentCellHd);

                double averageDiameter = model.calculateAverageDiameter(x, y, CANCER, QUIESCENTCANCER);

                model.collectTimeSeriesDataBayesianDelta(x, averageDiameter, k, 0 * timestepDay,
                        initialCancerCount, bayesianPriorsDelta[i], cancerTimeSeries);

                // main loop
                for (int j = 0; j < timesteps + 1; j++) {

                    if ((j % deltaTHatMultiplier == deltaTHatMultiplier - 1)) {
                        int indexValue = j / deltaTHatMultiplier;
                        // collect population data
                        double timeCount = j * 1 / timestepPerDay;
                        double cancerCn = model.populationType(CANCER);
                        double quiescentCancerCn = model.populationType(QUIESCENTCANCER);
                        timeVector[indexValue] = timeCount;
                        cancerPopulation[indexValue] = cancerCn;
                        quiescentCancerPopulation[indexValue] = quiescentCancerCn;

                        // age cells
                        model.ageCells(CANCER);

                        // divide cells
                        cellIDCount = model.divideCells(CANCER, cancerIMT / deltaTHatMultiplier,
                                bayesianPriors[0][0], cellIDCount);

                        // cancer cell proliferation update and age cancer cells
                        model.cancerDieProliferationUpdate(CANCER, QUIESCENTCANCER);

                        // calculate average diameter
                        averageDiameter = model.calculateAverageDiameter(x, y, CANCER, QUIESCENTCANCER);

                        boundaryReached = model.collectTimeSeriesDataBayesianDelta(x, averageDiameter, k,
                                (j + 1) * timestepDay, cancerCn + quiescentCancerCn,
                                bayesianPriorsDelta[i], cancerTimeSeries);

                    }

                    // update PDEGrid values
                    model.updatePDEValuesXenograftModelDelta(x, y, drugDiffusionCoefficientTimestep,
                            1, CANCER, QUIESCENTCANCER, betaVary, deltaVary);

                    // increment timestep
                    model.IncTick();

                    // check for cancer elimination to break loop
                    cancerEliminated = model.testElimination(CANCER, QUIESCENTCANCER);

                    // check for cancer elimination
                    if (cancerEliminated == true) {
                        break;
                    }

                    if (boundaryReached == true) {
                        break;
                    }

                }
            }

        }
        cancerTimeSeries.Close();

        // log end time of algorithm
        long endTime = System.nanoTime();
        // time elapsed
        long timeElapsed = endTime - startTime;
        long timeSeconds = timeElapsed / 1000000000;
        long timeMinutes = timeSeconds / 60;

        // indicate simulation has finished
        System.out.println("Simulation finished!");
        System.out.println("Time taken: " + timeSeconds + " seconds");
        System.out.println("Time taken: " + timeMinutes + " minutes");
    }
}



